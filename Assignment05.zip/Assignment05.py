#  Curtis Eng
#  Instructor Randall Root
#  IT FDN 100 A Python
#  Assignment 5
#  October 30, 2017

# This script maintains a file of Tasks and their Priorities.  The name of the file is ToDo.txt.
# The script reads the file and builds a dictionary from the existing data in the file.
# It then maintains the data in a list and prompts the user to either show the list, add new data,
# delete data, or save the data to update the file ToDo.txt

# Data Section #

objFileName = "./Todo.txt"  # Object that represents a file
charChoice = '1'            # Choice the user makes from menu initialized to 1
dicRow = {}                 # Row of dictionary data containing Task and Priority
lstTable = []               # A list containing the rows of dictionary entries
EXIT = '5'                  # Constant used to test if user wants to exit and stop script
WHITESPACE = 23             # Constant used for space formatting when displaying current list


# Input/Output Section #

def LoadDictionaryFromFile(): # Function that reads ToDo.txt and builds dictionary from the data
    fileToDoListFile = open(objFileName, "r")
    for Line in fileToDoListFile:
        strClean = Line.strip("\n")
        strTask, strPriority = strClean.split(",")
        dicRow[strTask] = strPriority
    fileToDoListFile.close()

def PopulateListTable(): # Function that moves the rows of data in dictionary into a List
    for strKey, strValue in dicRow.items():
        lstTempRow = [strKey, strValue]
        lstTable.append(lstTempRow)

def AddToList(): # Function that adds new Task/Priority row to the list
    strNewTask = input("What Task do you want to add?: ")
    for strCurrentTask, strCurrentPriority in lstTable:
        if strNewTask == strCurrentTask: # Make sure that new Task doesn't already exist
            print("That Task already exists. Cannot add or change existing Task\n")
            return
    strNewPriority = input("What priority is this?(L/M/H): ") # Prompts user to enter either 'L', 'M', or 'H'
    if strNewPriority[0].lower() == "l":
        strNewPriority = "low"
    elif strNewPriority[0].lower() == "m":
        strNewPriority = "medium"
    elif strNewPriority[0].lower() == "h":
        strNewPriority = "high"
    else: # User entered invalid Priority so exit out of function
        print("Invalid priority entry. Task not added.\n")
        return
    lstTempRow = [strNewTask, strNewPriority]
    lstTable.append(lstTempRow)
    print("Task and Priority have been added\n")

def RemoveFromList(): # Function that deletes existing Task/Priorty row from list
    strDelTask = input("What Task do you want to remove?: ")
    intIndex = 0
    for strTask, strPriority in lstTable:
        if strDelTask == strTask: # Found correct Task, delete it and exit function
            del lstTable[intIndex]
            print("Task and Priority have been deleted\n")
            return
        intIndex += 1
    print("Task does not exist.  Operation not successful\n") # If it gets to this point, Task doesn't exist

def WriteDataToFile(): # Function that writes the updated/existing list to ToDo.txt
    fileToDoListFile = open(objFileName, "w") # Start new ToDo.txt file
    for strTask, strPriority in lstTable:
        strFileData = strTask + "," + strPriority + "\n"
        fileToDoListFile.write(strFileData)
    fileToDoListFile.close()
    print("Data successfully written to file\n")

def GetUserChoice(): # Function that prints user menu and obtains user's choice
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4]: "))
    return (strChoice.strip())

def ShowCurrentData(): # Function that displays the current list
    print("*Task*                  *Priority*") # List header
    for strTask, strPriority in lstTable:
        print(str.ljust(strTask, WHITESPACE),strPriority) # Prints formatted list

def ProcessChoice(Choice): # Function that processes what the user has chosen to do
    if (Choice == '1'):     # Show current data
        ShowCurrentData()
        return
    elif (Choice == '2'):    # Add new item
        AddToList()
        return
    elif (Choice == '3'):    # Remove item
        RemoveFromList()
        return
    elif (Choice == '4'):    # Save data to ToDo.txt file
        WriteDataToFile()
        return
    elif (Choice == '5'):   # Exit and stop script
        print("Program terminated normally\n")
        return

# Processing Section #

LoadDictionaryFromFile() # Load data from ToDo.txt into a dictionary list
PopulateListTable() # Load dictionary list into a list table
while charChoice != EXIT: # Execute until user chooses to Exit
    charChoice = GetUserChoice() # Get user choice from menu options
    ProcessChoice(charChoice) # Process the what the user has chosen to do





