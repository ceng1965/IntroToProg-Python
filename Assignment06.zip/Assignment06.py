#  Curtis Eng
#  Instructor Randall Root
#  IT FDN 100 A Python
#  Assignment 6
#  November 1, 2017

# This script maintains a file of Tasks and their Priorities.  The name of the file is ToDo.txt.
# The script reads the file and builds a dictionary from the existing data in the file.
# It then maintains the data in a list and prompts the user to either show the list, add new data,
# delete data, or save the data to update the file ToDo.txt.
# This is all done through an object that is created from a class.

# Data Section #
EXIT = '5'                  # Constant used to test if user wants to exit and stop script

# Input/Output Section #
class ListOfTasksAndPriorties(object): # Create the class
    def __init__(self): # Constructor for the class
        self.objFileName = "./Todo.txt"  # Object that represents a file
        self.charChoice = '1'  # Choice the user makes from menu initialized to 1
        self.dicRow = {}  # Row of dictionary data containing Task and Priority
        self.lstTable = []  # A list containing the rows of dictionary entries
        self.WHITESPACE = 23  # Constant used for space formatting when displaying current list

    def LoadDictionaryAndList(self): # Function that reads ToDo.txt and builds dictionary and list
        fileToDoListFile = open(self.objFileName, "r")
        for Line in fileToDoListFile:
            strClean = Line.strip("\n")
            strTask, strPriority = strClean.split(",")
            self.dicRow[strTask] = strPriority
        fileToDoListFile.close()
        for strKey, strValue in self.dicRow.items():
            lstTempRow = [strKey, strValue]
            self.lstTable.append(lstTempRow)

    def AddToList(self): # Function that adds new Task/Priority row to the list
        strNewTask = input("What Task do you want to add?: ")
        for strCurrentTask, strCurrentPriority in self.lstTable:
            if strNewTask == strCurrentTask: # Make sure that new Task doesn't already exist
                print("That Task already exists. Cannot add or change existing Task\n")
                return
        strNewPriority = input("What priority is this?(L/M/H): ") # Prompts user to enter either 'L', 'M', or 'H'
        if strNewPriority[0].lower() == "l":
            strNewPriority = "low"
        elif strNewPriority[0].lower() == "m":
            strNewPriority = "medium"
        elif strNewPriority[0].lower() == "h":
            strNewPriority = "high"
        else: # User entered invalid Priority so exit out of function
            print("Invalid priority entry. Task not added.\n")
            return
        lstTempRow = [strNewTask, strNewPriority]
        self.lstTable.append(lstTempRow)
        print("Task and Priority have been added\n")

    def RemoveFromList(self): # Function that deletes existing Task/Priorty row from list
        strDelTask = input("What Task do you want to remove?: ")
        intIndex = 0
        for strTask, strPriority in self.lstTable:
            if strDelTask == strTask: # Found correct Task, delete it and exit function
                del self.lstTable[intIndex]
                print("Task and Priority have been deleted\n")
                return
            intIndex += 1
        print("Task does not exist.  Operation not successful\n") # If it gets to this point, Task doesn't exist

    def WriteDataToFile(self): # Function that writes the updated/existing list to ToDo.txt
        fileToDoListFile = open(self.objFileName, "w") # Start new ToDo.txt file
        for strTask, strPriority in self.lstTable:
            strFileData = strTask + "," + strPriority + "\n"
            fileToDoListFile.write(strFileData)
        fileToDoListFile.close()
        print("Data successfully written to file\n")

    def DisplayMenu(self): # Function that prints user menu and obtains user's choice
        print ("""
        Menu of Options
        1) Show current data
        2) Add a new item.
        3) Remove an existing item.
        4) Save Data to File
        5) Exit Program
        """)
        strChoice = str(input("Which option would you like to perform? [1 to 5]: "))
        self.charChoice = (strChoice.strip())

    def ShowCurrentData(self): # Function that displays the current list
        print("*Task*                  *Priority*") # List header
        for strTask, strPriority in self.lstTable:
            print(str.ljust(strTask, self.WHITESPACE),strPriority) # Prints formatted list

    def GetUserChoice(self): # Function that returns class attribute charChoice
        return self.charChoice

    def ProcessChoice(self): # Function that processes what the user has chosen to do
        if (self.charChoice == '1'):     # Show current data
            self.ShowCurrentData()
            return
        elif (self.charChoice == '2'):    # Add new item
            self.AddToList()
            return
        elif (self.charChoice == '3'):    # Remove item
            self.RemoveFromList()
            return
        elif (self.charChoice == '4'):    # Save data to ToDo.txt file
            self.WriteDataToFile()
            return
        elif (self.charChoice == '5'):   # Exit and stop script
            print("Program terminated normally\n")
            return

# Processing Section #
objTaskList = ListOfTasksAndPriorties() # Create new instance of Class
objTaskList.LoadDictionaryAndList() # Load data from file into dictionary then load list from dictionary
while objTaskList.GetUserChoice() != EXIT: # Execute until user chooses to Exit
    objTaskList.DisplayMenu() # Display menu and get user choice from menu options
    objTaskList.ProcessChoice() # Process the what the user has chosen to do
